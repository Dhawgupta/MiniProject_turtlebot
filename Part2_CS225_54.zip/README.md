# MiniProject_turtlebot
Try to build a sample turtle bot able to map the area
Dependencies

ROS Kinetic 
gmapping
navstack
rospy
std_msgs
sensor_msgs
SLAM
rosserial

